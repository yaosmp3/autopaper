# BetterTPA
# tpa datapack for minecraft

# Planet Minecraft post: https://www.planetminecraft.com/data-pack/bettertpa/

# Discord: https://discord.gg/BqkaSa82h5